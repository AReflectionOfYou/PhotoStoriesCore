# Sample photo stories: Photo Stories archive

This folder is a permanent, self-contained archive of the whole project: 3 photos, 2 stories, and 1 people. It needs no app or website. Keep it somewhere safe and make copies.

## Start here

Double-click **START HERE.html** at the top of this folder (next to the `data` folder). It opens in your web browser and shows every photo with its story and details. It needs no internet. If the photos don't appear, make sure the archive was unzipped first (on Windows: right-click the .zip file and choose Extract All).

## Looking at the photos

Every photo has its own folder in `data/photos/`:

- `original.*`: the picture exactly as it was copied in, never changed.
- `image.jpg`: the cropped and cleaned-up picture. Its title, story, date, place and the names of the people in it are written inside the file, so most photo programs show them.
- `thumb.jpg`: a small preview.
- `photo.json`: everything recorded about the photo (see below).

## What's in the JSON files

The `.json` files are plain text, readable in any text editor.

- `photo.json`: the photo's title, date and place (each with how sure the teller was), the story in the teller's own words and the raw transcript, who is in the photo and where their faces are, notes, where the photo came from, what edits were made, the full history of every change, and a Dublin Core description (`dublin_core`) for libraries and archives.
- `people.json`: everyone named, with other names they go by.
- `contributors.json`: who told the stories.
- `collections.json`, `events.json`: how the photos were grouped.
- `group.json`: the project itself.
- `manifest.json`: what this archive covers, the schema version, and when it was made.

Everything is linked by ids (long codes such as `3f2c…`): for example, a face's `person_id` matches an `id` in `people.json`.

### Dates

Dates are kept as they were said (`date_text`) and in the Library of Congress Extended Date/Time Format (`date_edtf`): `1965` a year, `1965-07` a month, `1965~` about 1965, `1965?` maybe 1965, `196X` sometime in the 1960s, `1965-22` summer 1965.

### Face regions

`faces` in `photo.json` give each face's box as fractions of `image.jpg`'s width and height (`bbox_x`, `bbox_y` = top-left corner, `bbox_w`, `bbox_h` = size).

## Checking the archive is complete

This folder is a BagIt "bag" (a Library of Congress standard). `manifest-sha256.txt` lists a checksum for every file, so you can confirm nothing has been damaged or lost, for example with the Library of Congress `bagit` tool: `bagit.py --validate <this folder>`.

## Bringing it back to life

Any version of Photo Stories can import this archive to restore the collection, move it to a new computer, or combine it with another.
